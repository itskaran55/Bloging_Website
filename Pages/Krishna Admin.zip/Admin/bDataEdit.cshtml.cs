//using BlogApp.Models;
//using Microsoft.AspNetCore.Mvc;
//using Microsoft.AspNetCore.Mvc.RazorPages;
//using Microsoft.Data.SqlClient;

//namespace BlogApp.Pages.Admin
//{
//    public class bDataEditModel : PageModel
//    {
//        [BindProperty]
//        public bModel bData { get; set; }

//        private string connectionString = "Server=Karannn-115\\SQLEXPRESS01;Database=BUsersTable;Trusted_Connection=True;Encrypt=False";
//        public void OnGet(int id)
//        {
//            using (SqlConnection con = new SqlConnection(connectionString))
//            {
//                string query = "SELECT * FROM BlogsData13 WHERE id = @id";

//                using (SqlCommand cmd = new SqlCommand(query, con))
//                {
//                    cmd.Parameters.AddWithValue("@id", id);
//                    con.Open();
//                    using (SqlDataReader reader = cmd.ExecuteReader())
//                    {
//                        if (reader.Read())
//                        {
//                            bData = new bModel
//                            {
//                                blogid = reader.GetInt32(0),
//                                title = reader.GetString(1),
//                                blogcontent = reader.GetString(2),
//                                isActive = reader.GetBoolean(5)
//                            };
//                        }
//                    }
//                }
//            }
//        }
//        public IActionResult OnPost()
//        {
//            using (SqlConnection con = new SqlConnection(connectionString))
//            {
//                string query = "UPDATE BlogsData13 SET title = @title, blogcontent = @blogcontent,isActive = @isActive WHERE id = @id";

//                using (SqlCommand cmd = new SqlCommand(query, con))
//                {
//                    cmd.Parameters.AddWithValue("@id", bData.blogid);
//                    cmd.Parameters.AddWithValue("@title", bData.title);
//                    cmd.Parameters.AddWithValue("@blogcontent", bData.blogcontent);
//                    if (Request.Form["isActive"].ToString() == "Select" || Request.Form["isActive"].ToString() == "1")
//                    {
//                        cmd.Parameters.AddWithValue("@isActive", true);
//                    }
//                    else
//                    {
//                        cmd.Parameters.AddWithValue("@isActive", false);
//                    }

//                    con.Open();
//                    int rowsAffected = cmd.ExecuteNonQuery();
//                    if (rowsAffected > 0)
//                    {
//                        return RedirectToPage("/Admin/blogsData");
//                    }
//                    //cmd.ExecuteNonQuery();
//                    con.Close();
//                }
//            }
//            return Page();
//        }
//    }
//}

using BlogApp.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.Data.SqlClient;

namespace BlogApp.Pages.Admin
{
    public class bDataEditModel : PageModel
    {
        [BindProperty]
        public bModel bData { get; set; }

        private string connectionString = "Server=Karannn-115\\SQLEXPRESS01;Database=BUsersTable;Trusted_Connection=True;Encrypt=False";

        public void OnGet(int id)
        {
            using (SqlConnection con = new SqlConnection(connectionString))
            {
                string query = "SELECT * FROM BlogsData13 WHERE id = @id";

                using (SqlCommand cmd = new SqlCommand(query, con))
                {
                    cmd.Parameters.AddWithValue("@id", id);
                    con.Open();
                    using (SqlDataReader reader = cmd.ExecuteReader())
                    {
                        if (reader.Read())
                        {
                            bData = new bModel
                            {
                                blogid = reader.GetInt32(0),
                                title = reader.GetString(1),
                                blogcontent = reader.GetString(2),
                                isActive = reader.GetBoolean(5)
                            };
                        }
                    }
                }
            }
        }

        public IActionResult OnPost()
        {
            if (!ModelState.IsValid)
            {
                return Page();
            }

            using (SqlConnection con = new SqlConnection(connectionString))
            {
                string query = "UPDATE BlogsData13 SET title = @title, blogcontent = @blogcontent, isActive = @isActive WHERE id = @id";

                using (SqlCommand cmd = new SqlCommand(query, con))
                {
                    cmd.Parameters.AddWithValue("@id", bData.blogid);
                    cmd.Parameters.AddWithValue("@title", bData.title);
                    cmd.Parameters.AddWithValue("@blogcontent", bData.blogcontent ?? string.Empty); // Ensure blogcontent is not null
                    cmd.Parameters.AddWithValue("@isActive", Request.Form["isActive"].ToString() == "Select" || Request.Form["isActive"].ToString() == "1");

                    con.Open();
                    int rowsAffected = cmd.ExecuteNonQuery();
                    con.Close();

                    if (rowsAffected > 0)
                    {
                        return RedirectToPage("/Admin/blogsData");
                    }
                }
            }

            // Reload the blog data in case of failure
            LoadBlogData(bData.blogid);

            return Page();
        }

        private void LoadBlogData(int id)
        {
            using (SqlConnection con = new SqlConnection(connectionString))
            {
                string query = "SELECT * FROM BlogsData13 WHERE id = @id";

                using (SqlCommand cmd = new SqlCommand(query, con))
                {
                    cmd.Parameters.AddWithValue("@id", id);
                    con.Open();
                    using (SqlDataReader reader = cmd.ExecuteReader())
                    {
                        if (reader.Read())
                        {
                            bData = new bModel
                            {
                                blogid = reader.GetInt32(0),
                                title = reader.GetString(1),
                                blogcontent = reader.GetString(2),
                                isActive = reader.GetBoolean(5)
                            };
                        }
                    }
                }
            }
        }
    }
}

